<button onclick="init()">Start</button><br />
<article id="mov"></article>
<canvas id="cadre" height="450px" width="450px">
	Votre navigateur ne supporte pas les canvas !
</canvas>