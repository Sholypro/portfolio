<footer>
    <h5>© Lopez Alexandre TP php</h5>
</footer>